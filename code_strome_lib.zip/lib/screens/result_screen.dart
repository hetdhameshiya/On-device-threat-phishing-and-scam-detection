import 'package:flutter/material.dart';

import '../models/risk_result.dart';
import 'golden_hour_screen.dart';

class ResultScreen extends StatelessWidget {
  final String text;
  final RiskResult result;

  const ResultScreen({super.key, required this.text, required this.result});

  MaterialColor get _color => switch (result.level) {
        RiskLevel.safe => Colors.green,
        RiskLevel.suspicious => Colors.orange,
        RiskLevel.dangerous => Colors.red,
      };

  List<TextSpan> _buildSpans() {
    final sorted = result.highlights
        .where((r) => r[1] <= text.length)
        .toList()
      ..sort((a, b) => a[0].compareTo(b[0]));

    final merged = <List<int>>[];
    for (final r in sorted) {
      if (merged.isNotEmpty && r[0] <= merged.last[1]) {
        if (r[1] > merged.last[1]) merged.last[1] = r[1];
      } else {
        merged.add([r[0], r[1]]);
      }
    }

    final spans = <TextSpan>[];
    var pos = 0;
    for (final r in merged) {
      if (r[0] > pos) spans.add(TextSpan(text: text.substring(pos, r[0])));
      spans.add(TextSpan(
        text: text.substring(r[0], r[1]),
        style: TextStyle(
          backgroundColor: Colors.red.shade100,
          fontWeight: FontWeight.bold,
        ),
      ));
      pos = r[1];
    }
    if (pos < text.length) spans.add(TextSpan(text: text.substring(pos)));
    return spans;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final c = _color;

    return Scaffold(
      appBar: AppBar(title: const Text('Result')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // 1. Verdict
          Card(
            color: c.shade50,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 38,
                    backgroundColor: c.shade700,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text('${result.score}',
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 26,
                                fontWeight: FontWeight.bold)),
                        const Text('/100',
                            style:
                                TextStyle(color: Colors.white, fontSize: 11)),
                      ],
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(result.headline,
                            style: theme.textTheme.titleLarge?.copyWith(
                                fontWeight: FontWeight.bold,
                                color: c.shade900)),
                        const SizedBox(height: 8),
                        Text(result.advice),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          // 2. Scam tricks (Explain Why)
          if (result.tactics.isNotEmpty) ...[
            const SizedBox(height: 16),
            Text('Scam tricks found',
                style: theme.textTheme.titleMedium
                    ?.copyWith(fontWeight: FontWeight.bold)),
            ...result.tactics.map((t) => Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.warning_amber, color: c.shade700),
                            const SizedBox(width: 8),
                            Text(t.label,
                                style: theme.textTheme.titleSmall
                                    ?.copyWith(fontWeight: FontWeight.bold)),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text(t.explanation),
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 6,
                          runSpacing: 4,
                          children: t.matched
                              .map((m) => Chip(
                                    label: Text(m),
                                    visualDensity: VisualDensity.compact,
                                  ))
                              .toList(),
                        ),
                      ],
                    ),
                  ),
                )),
          ],

          // 3. Links and UPI
          if (result.links.isNotEmpty) ...[
            const SizedBox(height: 16),
            Text('Links and payments',
                style: theme.textTheme.titleMedium
                    ?.copyWith(fontWeight: FontWeight.bold)),
            ...result.links.map((l) => Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(l.isUpi ? Icons.payments : Icons.link,
                                color: c.shade700),
                            const SizedBox(width: 8),
                            Text(l.isUpi ? 'UPI payment link' : 'Web link',
                                style: theme.textTheme.titleSmall
                                    ?.copyWith(fontWeight: FontWeight.bold)),
                          ],
                        ),
                        const SizedBox(height: 4),
                        SelectableText(l.url,
                            style: const TextStyle(fontFamily: 'monospace')),
                        const SizedBox(height: 8),
                        ...l.reasons.map((r) => Padding(
                              padding: const EdgeInsets.only(bottom: 4),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text('\u2022  '),
                                  Expanded(child: Text(r)),
                                ],
                              ),
                            )),
                      ],
                    ),
                  ),
                )),
          ],

          if (result.tactics.isEmpty && result.links.isEmpty) ...[
            const SizedBox(height: 16),
            const Text('No known scam tricks or risky links were found.'),
          ],

          // 4. The message with dangerous words highlighted
          const SizedBox(height: 16),
          Text('Your message',
              style: theme.textTheme.titleMedium
                  ?.copyWith(fontWeight: FontWeight.bold)),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Text.rich(
                TextSpan(
                  style: theme.textTheme.bodyLarge,
                  children: _buildSpans(),
                ),
              ),
            ),
          ),

          // 5. Actions
          const SizedBox(height: 16),
          FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: Colors.red.shade700),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) =>
                    GoldenHourScreen(text: text, result: result),
              ),
            ),
            icon: const Icon(Icons.emergency),
            label: const Padding(
              padding: EdgeInsets.symmetric(vertical: 12),
              child: Text('I think I was scammed',
                  style: TextStyle(fontSize: 18)),
            ),
          ),
          const SizedBox(height: 8),
          OutlinedButton(
            onPressed: () => Navigator.pop(context),
            child: const Padding(
              padding: EdgeInsets.symmetric(vertical: 12),
              child: Text('Check another message'),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'This is a warning tool, not a guarantee. Rules-based for now; the learned model comes next.',
            style: TextStyle(fontSize: 12, color: Colors.black54),
          ),
        ],
      ),
    );
  }
}
