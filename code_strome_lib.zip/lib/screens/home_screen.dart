import 'package:flutter/material.dart';

import '../services/rules_engine.dart';
import 'result_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _controller = TextEditingController();

  static const Map<String, String> _samples = {
    'Bank KYC (Gujarati)':
        'તમારું બેંક ખાતું બંધ થઈ જશે. તાત્કાલિક KYC અપડેટ કરો: http://sbi-kyc.top/login',
    'Lottery lure':
        'Congratulations! You have won Rs 25,00,000 in KBC lucky draw. Pay Rs 5,000 processing fee to claim your prize. Do not tell anyone.',
    'UPI refund trick':
        'Refund of Rs 4,999 is ready. Tap to receive: upi://pay?pa=refund.desk@oksbi&pn=Amazon%20Refund&am=4999',
    'Real OTP (safe)':
        'Your OTP is 482913 for login to Amazon. Do not share it with anyone.',
  };

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _analyze() {
    final text = _controller.text.trim();
    if (text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Paste or type a message first.')),
      );
      return;
    }
    final result = RulesEngine.analyze(text);
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ResultScreen(text: text, result: result),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Code Strome'),
        leading: const Icon(Icons.shield),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Got a suspicious message?',
                style: theme.textTheme.headlineSmall
                    ?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            const Text(
                'Paste the SMS, WhatsApp message, link or UPI link. We check it before you act.'),
            const SizedBox(height: 16),
            TextField(
              controller: _controller,
              maxLines: 6,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'Paste message here...',
              ),
            ),
            const SizedBox(height: 12),
            Text('Try an example:', style: theme.textTheme.labelLarge),
            const SizedBox(height: 4),
            Wrap(
              spacing: 8,
              children: _samples.entries
                  .map((e) => ActionChip(
                        label: Text(e.key),
                        onPressed: () =>
                            setState(() => _controller.text = e.value),
                      ))
                  .toList(),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: _analyze,
                icon: const Icon(Icons.search),
                label: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 12),
                  child: Text('Check this message',
                      style: TextStyle(fontSize: 18)),
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Row(
              children: [
                Icon(Icons.lock, size: 18),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                      'Checked on your phone. Your message is never uploaded.'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
