import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/risk_result.dart';

class GoldenHourScreen extends StatelessWidget {
  final String text;
  final RiskResult result;

  const GoldenHourScreen({super.key, required this.text, required this.result});

  static const List<(IconData, String, String)> _steps = [
    (
      Icons.call,
      'Call 1930 now',
      "India's national cyber fraud helpline. Open your phone dialer and dial 1930. Report as fast as you can: speed matters."
    ),
    (
      Icons.account_balance,
      'Tell your bank',
      'Call the number on the back of your card or in your bank app. Ask them to block the card, UPI and net banking.'
    ),
    (
      Icons.language,
      'File a report online',
      'Go to cybercrime.gov.in and file a complaint. Keep the transaction ID and amount ready.'
    ),
    (
      Icons.photo_camera,
      'Save the evidence',
      'Do not delete the message, call log or payment receipt. Take screenshots. Use the button below to copy a summary.'
    ),
    (
      Icons.lock_reset,
      'Secure your accounts',
      'Change your passwords, turn on two-step verification, and remove any app the scammer asked you to install.'
    ),
    (
      Icons.groups,
      'Warn family and contacts',
      'Tell people close to you so the same scammer cannot reach them through you.'
    ),
  ];

  String _summary() {
    final b = StringBuffer();
    b.writeln('Message received:');
    b.writeln(text);
    b.writeln();
    b.writeln('Why it looks like a scam (Code Strome check):');
    for (final t in result.tactics) {
      b.writeln('- ${t.label}: ${t.matched.join(", ")}');
    }
    for (final l in result.links) {
      b.writeln('- Link: ${l.url}');
      for (final r in l.reasons) {
        b.writeln('    * $r');
      }
    }
    b.writeln();
    b.writeln('Noted at: ${DateTime.now()}');
    return b.toString();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Golden Hour: act now'),
        backgroundColor: Colors.red.shade700,
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Stay calm. Do these steps in order.',
              style: theme.textTheme.titleLarge
                  ?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          ..._steps.indexed.map((e) {
            final i = e.$1;
            final s = e.$2;
            return Card(
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.red.shade50,
                  child: Icon(s.$1, color: Colors.red.shade700),
                ),
                title: Text('${i + 1}. ${s.$2}',
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(s.$3),
              ),
            );
          }),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: _summary()));
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                      content: Text('Evidence summary copied. Paste it into your complaint.')),
                );
              }
            },
            icon: const Icon(Icons.copy),
            label: const Padding(
              padding: EdgeInsets.symmetric(vertical: 12),
              child: Text('Copy evidence summary'),
            ),
          ),
        ],
      ),
    );
  }
}
