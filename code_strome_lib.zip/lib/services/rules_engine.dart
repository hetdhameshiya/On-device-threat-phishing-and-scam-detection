import '../models/risk_result.dart';

class _TacticDef {
  final String id;
  final String label;
  final String explain;
  final int weight;
  final List<String> keywords;
  const _TacticDef(
      this.id, this.label, this.explain, this.weight, this.keywords);
}

/// On-device rule engine. Everything runs on the phone, nothing is uploaded.
/// Idea: detect the MANIPULATION (tactics), not just known bad words.
class RulesEngine {
  static const List<_TacticDef> _tactics = [
    _TacticDef(
      'urgency',
      'Urgency',
      'Scammers rush you so you do not stop and think.',
      15,
      [
        'urgent', 'urgently', 'immediately', 'right now', 'last chance',
        'within 24 hours', 'expires today', 'act now', 'hurry', 'today only',
        'asap', 'turant', 'jaldi', 'abhi', 'aaj hi',
        'તાત્કાલિક', 'જલ્દી', 'હમણાં જ',
        'आज ही', 'तुरंत', 'जल्दी', 'अभी',
      ],
    ),
    _TacticDef(
      'fear',
      'Fear and threat',
      'Scammers scare you with blocking, arrest or penalties so you obey.',
      25,
      [
        'account blocked', 'will be blocked', 'blocked', 'suspended',
        'will be closed', 'legal action', 'arrest', 'warrant', 'digital arrest',
        'cbi', 'narcotics', 'kyc expired', 'sim will be', 'block ho', 'band ho',
        'penalty', 'court notice', 'police',
        'બ્લોક', 'બંધ થઈ જશે', 'ધરપકડ', 'પોલીસ', 'કાનૂની',
        'ब्लॉक', 'बंद हो', 'गिरफ्तार', 'पुलिस', 'कानूनी',
      ],
    ),
    _TacticDef(
      'authority',
      'Fake authority',
      'Scammers pretend to be a bank, government office or courier to gain trust.',
      10,
      [
        'rbi', 'sbi', 'hdfc', 'icici', 'axis bank', 'paytm', 'phonepe',
        'income tax', 'customs', 'courier', 'fedex', 'trai', 'cyber crime',
        'cyber cell', 'officer', 'electricity', 'aadhaar', 'uidai', 'epfo',
        'bank',
        'બેંક', 'સરકાર', 'અધિકારી',
        'बैंक', 'सरकार', 'अधिकारी',
      ],
    ),
    _TacticDef(
      'secrecy',
      'Secrecy',
      'Scammers tell you to keep it secret so nobody can warn you.',
      25,
      [
        'do not tell', 'dont tell', 'tell no one', 'keep it secret',
        'keep this secret', 'confidential', 'do not inform', 'do not disclose',
        'kisi ko mat batana', 'kisi ko na batao',
        'કોઈને કહેતા નહીં', 'કોઈને ન કહેવું',
        'किसी को मत बताना', 'किसी को न बताएं',
      ],
    ),
    _TacticDef(
      'money_request',
      'Money request',
      'Real offices do not ask you to pay a fee or send money like this.',
      25,
      [
        'processing fee', 'registration fee', 'security deposit',
        'advance payment', 'send money', 'transfer money', 'pay now',
        'collect request', 'approve the request', 'pay a fee',
        'paise bhejo', 'paisa bhejo',
        'પૈસા મોકલો', 'પૈસા ટ્રાન્સફર',
        'पैसे भेज',
      ],
    ),
    _TacticDef(
      'credential_request',
      'Asks for secrets or app install',
      'No bank or company will ask for your OTP, PIN, password or ask you to install a remote-control app.',
      30,
      [
        'share otp', 'send otp', 'tell otp', 'give otp', 'otp batao',
        'otp bhejo', 'your pin', 'enter pin', 'upi pin', 'cvv', 'card number',
        'password', 'anydesk', 'teamviewer', 'quicksupport',
        'install this app', 'download this apk', '.apk',
        'ઓટીપી શેર', 'ઓટીપી જણાવો',
        'ओटीपी बताएं', 'ओटीपी बताओ', 'ओटीपी शेयर',
      ],
    ),
    _TacticDef(
      'lure',
      'Lure and greed',
      'Scammers dangle prizes, easy money or jobs. If it sounds too good to be true, it is.',
      20,
      [
        'you have won', 'you won', 'winner', 'lucky draw', 'prize',
        'congratulations', 'free gift', 'gift voucher', 'lottery', 'jackpot',
        'kbc', 'work from home', 'earn from home', 'easy money',
        'part time job', 'daily income', 'double your money',
        'guaranteed returns', 'high returns', 'investment opportunity',
        'crypto', 'ghar baithe kamao', 'inam',
        'લોટરી', 'ઇનામ', 'જીત્યા', 'ઘરે બેઠા કમાઓ',
        'लॉटरी', 'इनाम', 'जीते', 'घर बैठे कमाएं',
      ],
    ),
  ];

  // "Do not share your OTP" is a warning, not a scam. We mask those phrases
  // before looking for credential requests.
  static final RegExp _negation = RegExp(
      r"(do not|don't|dont|never)\s+(share|tell|give|disclose)[^.\n]*");

  static final RegExp _asciiOnly = RegExp(r'^[\x00-\x7F]+$');
  static final RegExp _upiRe = RegExp(r'upi://[^\s]+', caseSensitive: false);
  static final RegExp _urlRe =
      RegExp(r'(?:https?://|www\.)[^\s<>"]+', caseSensitive: false);
  static final RegExp _shortRe = RegExp(
      r'\b(?:bit\.ly|tinyurl\.com|t\.co|goo\.gl|rb\.gy|cutt\.ly|is\.gd|shorturl\.at|tiny\.cc)/[^\s]*',
      caseSensitive: false);

  static const Set<String> _shorteners = {
    'bit.ly', 'tinyurl.com', 't.co', 'goo.gl', 'rb.gy', 'cutt.ly', 'is.gd',
    'shorturl.at', 'tiny.cc',
  };

  static const List<String> _riskyTlds = [
    '.xyz', '.top', '.click', '.work', '.loan', '.gq', '.tk', '.ml', '.cf',
    '.icu', '.buzz', '.rest', '.cam', '.monster', '.help',
  ];

  static const List<String> _brands = [
    'sbi', 'hdfc', 'icici', 'axis', 'paytm', 'phonepe', 'amazon', 'flipkart',
    'irctc', 'uidai', 'aadhaar', 'epfo', 'incometax', 'npci', 'airtel',
  ];

  static const List<String> _officialDomains = [
    'sbi.co.in', 'onlinesbi.sbi', 'hdfcbank.com', 'icicibank.com',
    'axisbank.com', 'paytm.com', 'phonepe.com', 'amazon.in', 'amazon.com',
    'flipkart.com', 'irctc.co.in', 'uidai.gov.in', 'epfindia.gov.in',
    'incometax.gov.in', 'npci.org.in', 'airtel.in', 'gov.in', 'nic.in',
  ];

  // ---------------------------------------------------------------------

  static RiskResult analyze(String text) {
    final lower = text.toLowerCase();
    final masked = lower.replaceAllMapped(
        _negation, (m) => ' ' * (m.end - m.start));

    final hits = <TacticHit>[];
    final ranges = <List<int>>[];
    var score = 0;

    for (final t in _tactics) {
      final source = t.id == 'credential_request' ? masked : lower;
      final matched = <String>[];
      for (final kw in t.keywords) {
        final found = _findAll(source, kw);
        if (found.isNotEmpty) {
          matched.add(kw);
          ranges.addAll(found);
        }
      }
      if (matched.isNotEmpty) {
        hits.add(TacticHit(
          id: t.id,
          label: t.label,
          explanation: t.explain,
          matched: matched,
        ));
        score += t.weight;
      }
    }

    final links = _extractLinks(text, lower);
    var linkScore = 0;
    for (final l in links) {
      if (l.score > linkScore) linkScore = l.score;
    }
    score += linkScore;

    // Several tricks together is a strong sign of a scam.
    if (hits.length >= 3) score += 15;
    if (score > 100) score = 100;

    final level = score >= 55
        ? RiskLevel.dangerous
        : score >= 25
            ? RiskLevel.suspicious
            : RiskLevel.safe;

    return RiskResult(
      score: score,
      level: level,
      tactics: hits,
      links: links,
      highlights: ranges,
    );
  }

  // ---------------------------------------------------------------------

  static List<List<int>> _findAll(String lower, String kw) {
    final out = <List<int>>[];
    if (_asciiOnly.hasMatch(kw)) {
      final startsWord = RegExp(r'^\w').hasMatch(kw);
      final endsWord = RegExp(r'\w$').hasMatch(kw);
      final pattern = (startsWord ? r'\b' : '') +
          RegExp.escape(kw) +
          (endsWord ? r'\b' : '');
      for (final m in RegExp(pattern).allMatches(lower)) {
        out.add([m.start, m.end]);
      }
    } else {
      // Gujarati / Hindi: simple substring search.
      var i = lower.indexOf(kw);
      while (i != -1) {
        out.add([i, i + kw.length]);
        i = lower.indexOf(kw, i + kw.length);
      }
    }
    return out;
  }

  static List<LinkFinding> _extractLinks(String text, String lower) {
    final findings = <LinkFinding>[];
    final seen = <String>{};
    String clean(String s) => s.replaceAll(RegExp(r'[).,;!?]+$'), '');

    for (final m in _upiRe.allMatches(text)) {
      final raw = clean(m.group(0)!);
      if (seen.add(raw)) findings.add(_checkUpi(raw, lower));
    }

    final urls = <String>[];
    for (final m in _urlRe.allMatches(text)) {
      final raw = clean(m.group(0)!);
      if (seen.add(raw)) {
        urls.add(raw);
        findings.add(_checkUrl(raw));
      }
    }

    for (final m in _shortRe.allMatches(text)) {
      final raw = clean(m.group(0)!);
      if (urls.any((u) => u.contains(raw))) continue;
      if (seen.add(raw)) findings.add(_checkUrl(raw));
    }
    return findings;
  }

  static LinkFinding _checkUrl(String raw) {
    final reasons = <String>[];
    var score = 0;

    final explicit = raw.contains('://');
    final uri = Uri.tryParse(explicit ? raw : 'http://$raw');
    if (uri == null || uri.host.isEmpty) {
      return LinkFinding(
        url: raw,
        isUpi: false,
        reasons: ['Could not read this link properly.'],
        score: 10,
      );
    }
    final host = uri.host.toLowerCase();

    if (_shorteners.contains(host)) {
      reasons.add('Shortened link: it hides the real website.');
      score += 15;
    }
    if (RegExp(r'^\d{1,3}(\.\d{1,3}){3}$').hasMatch(host)) {
      reasons.add('Uses a number address instead of a website name.');
      score += 25;
    }
    if (uri.userInfo.isNotEmpty) {
      reasons.add('Contains an @ trick: the real site is after the @.');
      score += 25;
    }
    if (raw.toLowerCase().startsWith('http://')) {
      reasons.add('Not secure (http, not https).');
      score += 5;
    }
    if (host.contains('xn--')) {
      reasons.add('Uses look-alike letters in the website name.');
      score += 25;
    }
    if (_riskyTlds.any((t) => host.endsWith(t))) {
      reasons.add('Website ending is often used in scams.');
      score += 15;
    }
    if ('-'.allMatches(host).length >= 2) {
      reasons.add('Many hyphens in the website name.');
      score += 10;
    }
    for (final b in _brands) {
      if (host.contains(b)) {
        final official = _officialDomains
            .any((d) => host == d || host.endsWith('.$d'));
        if (!official) {
          reasons.add(
              'Name looks like ${b.toUpperCase()} but this is not its official website.');
          score += 35;
        }
        break;
      }
    }
    final words = ['login', 'verify', 'secure', 'kyc', 'reward', 'claim', 'gift', 'update']
        .where((w) => host.contains(w))
        .toList();
    if (words.isNotEmpty) {
      reasons.add('Pressure words in the address: ${words.join(", ")}.');
      score += 10;
    }

    if (reasons.isEmpty) {
      reasons.add(
          'No red flags in the address itself. We check only the address, not the page behind it.');
    }
    if (score > 60) score = 60;
    return LinkFinding(url: raw, isUpi: false, reasons: reasons, score: score);
  }

  static LinkFinding _checkUpi(String raw, String lowerText) {
    final reasons = <String>[];
    var score = 40;
    var q = <String, String>{};
    try {
      q = Uri.parse(raw)
          .queryParameters
          .map((k, v) => MapEntry(k.toLowerCase(), v));
    } catch (_) {}

    reasons.add('This opens a UPI payment. Money goes OUT of your account.');
    final pa = q['pa'] ?? 'ID unknown';
    final pn = q['pn'] ?? 'name hidden';
    reasons.add('Payee: $pn ($pa)');
    final am = q['am'];
    if (am != null) reasons.add('Amount already filled in: Rs $am');

    const bait = [
      'receive', 'refund', 'cashback', 'claim', 'prize', 'reward', 'get money'
    ];
    if (bait.any((w) => lowerText.contains(w))) {
      reasons.add(
          'The message says you will receive money. A UPI link or QR code only PAYS, it never receives.');
      score += 25;
    }
    return LinkFinding(url: raw, isUpi: true, reasons: reasons, score: score);
  }
}
