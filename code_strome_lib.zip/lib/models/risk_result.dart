enum RiskLevel { safe, suspicious, dangerous }

/// One scam trick found in the message (urgency, fear, lure...).
class TacticHit {
  final String id;
  final String label;
  final String explanation;
  final List<String> matched;

  const TacticHit({
    required this.id,
    required this.label,
    required this.explanation,
    required this.matched,
  });
}

/// One link (web address or UPI payment link) found in the message.
class LinkFinding {
  final String url;
  final bool isUpi;
  final List<String> reasons;
  final int score;

  const LinkFinding({
    required this.url,
    required this.isUpi,
    required this.reasons,
    required this.score,
  });
}

class RiskResult {
  final int score; // 0 to 100
  final RiskLevel level;
  final List<TacticHit> tactics;
  final List<LinkFinding> links;

  /// [start, end] positions in the original text to highlight.
  final List<List<int>> highlights;

  const RiskResult({
    required this.score,
    required this.level,
    required this.tactics,
    required this.links,
    required this.highlights,
  });

  String get headline => switch (level) {
        RiskLevel.safe => 'No scam tricks found',
        RiskLevel.suspicious => 'Be careful: this looks suspicious',
        RiskLevel.dangerous => 'Dangerous: this is very likely a scam',
      };

  String get advice => switch (level) {
        RiskLevel.safe =>
          'Nothing risky was detected. Still, never share your OTP, PIN or password with anyone.',
        RiskLevel.suspicious =>
          'Do not click, pay or share details yet. Verify by calling the official number from the bank app or website.',
        RiskLevel.dangerous =>
          'Do not click, pay or reply. Never share an OTP or PIN. Block the sender. If you already paid or shared details, tap the red button below.',
      };
}
