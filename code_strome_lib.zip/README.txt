Code Strome - first app screens (Flutter, no extra packages)

1. Unzip this into your project folder: C:\Users\dhame\StudioProjects\code_strome
   (it contains a lib/ folder; allow it to replace lib/main.dart)
2. Delete test\widget_test.dart (it tests the old demo counter app)
3. Select your phone in the device dropdown and press Run.
